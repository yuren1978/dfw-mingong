/**
 * Created by jianweisun on 12/20/15.
 */
(function() {
  'use strict';

  angular
    .module('starter')
    .constant('FIREBASE_URL', 'https://blinding-inferno-2256.firebaseio.com');

})();
